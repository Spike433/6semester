package raytracing;

public class Triangle {

}
