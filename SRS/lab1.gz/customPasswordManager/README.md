# KeePass

Simple app that demonstrates how password manager works.

## How To Use

### Install packages

```bash

./installPackages.sh

```

### Run app

```

./runKeePass.sh 

```

## Specifications

The security requirements are met because whenever we encrypt a file, we use a master password with a randomly generated salt that is stored in the file (a bonus, even if it is not security-related). 

AES-GCM is used so we know if an attacker has tried to modify the file. Also, the data in the binary is shuffled with random new lines (a plus for security).

With scypt we get the best permonace to memory ratio.

Intergity is also not a problem since we have authentication for the master password.

