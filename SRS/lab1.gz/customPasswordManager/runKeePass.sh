

python keePass.py init pass
sleep 2

echo 
echo "Access keePass with wrong master password"
echo  "./keePass.py get wrongMaster username"
python ./keePass.py get wrongMaster username
sleep 2

echo
echo "Access keePass with correct master password but empty database"
echo "./keePass.py get pass username"
python ./keePass.py get pass username
sleep 2

echo
echo "Try to write wrongMaster username1 password1"
echo "./keePass.py put wrongMaster username1 password1"
python ./keePass.py put wrongMaster username1 password1
sleep 2

echo
echo "Insert pass username1 password1"
echo "./keePass.py put pass username1 password1"
python ./keePass.py put pass username1 password1
sleep 2

echo
echo "Insert pass username2 password2"
echo "./keePass.py put pass username2 password2"
python ./keePass.py put pass username2 password2
sleep 2

echo
echo "Insert pass username3 password3"
echo "./keePass.py put pass username3 password3"
python ./keePass.py put pass username3 password3
sleep 2

echo
echo "Overwrite password for username2"
echo "./keePass.py put pass username2 overwrittenPassword"
python ./keePass.py put pass username2 overwrittenPassword
sleep 2

echo
echo "Type wrong masterpassword but correct username"
echo "./keePass.py get wrong username2"
python ./keePass.py get wrong username2 
sleep 2

echo
echo "Get overwritten passwod"
echo "./keePass.py get pass  username2"
python ./keePass.py get pass  username2 
sleep 2
