import random
import sys
import os
from Crypto.Cipher import AES
from Crypto.Protocol.KDF import PBKDF2
from Crypto.Hash import SHA512
from Crypto.Random import get_random_bytes
from Crypto.Protocol.KDF import scrypt

inpFile = 'inputFile.txt'

outputSecret = inpFile + '.secret'
outputForDecryption = inpFile
inputDecrypt = 'inputFile.txt.secret'


class FormatCredentials:
    def __init__(self, name, password):
        self.name = name
        self.password = password

    def __str__(self):
        return self.name + " " + self.password + "\n"


def encrypt(password):
    global inpFile, outputSecret

    buffer_size = setBufferSize()

    inBytesFile, outBytesFile = openFiles(inpFile, outputSecret)

    keyScript = writeSaltAndKey(outBytesFile, password)

    ciph = AES.new(keyScript, AES.MODE_GCM)
    outBytesFile.write(ciph.nonce)

    readData(buffer_size, ciph, inBytesFile, outBytesFile)

    tagVerification = ciph.digest()
    outBytesFile.write(tagVerification)

    closeFiles(inBytesFile, outBytesFile)


def writeSaltAndKey(outBytesFile, password):
    salt = get_random_bytes(32)  # Generate salt
    keyScript = scrypt(password, salt, key_len=32, N=2 ** 17, r=8, p=1)
    outBytesFile.write(salt)
    return keyScript


def readData(buffer, ciph, inBytesFile, outBytesFile):
    userData = inBytesFile.read(buffer)
    while len(userData) != 0:
        dataEncry = ciph.encrypt(userData)
        outBytesFile.write(dataEncry)
        userData = inBytesFile.read(buffer)


def openFiles(inpFile, outputSecret):
    inBytesFile = open(inpFile, 'rb')
    outBytesFile = open(outputSecret, 'wb')
    return inBytesFile, outBytesFile


def closeFiles(inBytesFile, outBytesFile):
    inBytesFile.close()
    outBytesFile.close()


def decrypt(masterPassword):
    global inputDecrypt, outputForDecryption

    buffer_size = setBufferSize()

    inputBinary, outBinary = openFiles(inputDecrypt, outputForDecryption)

    salt = inputBinary.read(32)
    keyForCipher = scrypt(masterPassword, salt, key_len=32, N=2 ** 17, r=8, p=1)

    getNonce = inputBinary.read(16)
    getCipher = AES.new(keyForCipher, AES.MODE_GCM, nonce=getNonce)

    # salt is 32, getNonce 16 data x, tag 16, determine how many bytes of encrypted data is

    readDecryData(buffer_size, getCipher, inputBinary, inputDecrypt, outBinary)

    verifivationTag = inputBinary.read(16)
    try:
        getCipher.verify(verifivationTag)
    except ValueError as e:
        inputBinary.close()
        outBinary.close()
        os.remove(outputForDecryption)
        return False

    closeFiles(inputBinary, outBinary)
    os.remove(inputDecrypt)
    return True


def readDecryData(buffer_size, getCipher, inputBinary, inputDecrypt, outBinary):
    fileSize = os.path.getsize(inputDecrypt)
    encryDataSize = fileSize - 32 - 16 - 16  # Total - salt - getNonce - tag = encrypted data
    for _ in range(int(encryDataSize / buffer_size)):
        binaryData = inputBinary.read(buffer_size)
        decryData = getCipher.decrypt(binaryData)
        outBinary.write(decryData)

    binaryData = inputBinary.read(int(encryDataSize % buffer_size))

    decryData = getCipher.decrypt(binaryData)

    outBinary.write(decryData)


def setBufferSize():
    buffer_size = 1024 * 1024
    return buffer_size


def openFilesInDecrypt(inputDecrypt, outputForDecryption):
    inputBinary = open(inputDecrypt, 'rb')
    outputBinary = open(outputForDecryption, 'wb')
    return inputBinary, outputBinary


def FindUsername(username, type):
    global inpFile
    f = open(inpFile, "r")
    lines = f.readlines()

    for credential in lines:
        if credential.__contains__(username):
            if type == "get":
                usrName = credential.split(" ")[0]
                passw = credential.split(" ")[1]
                return "Password for " + usrName + " is: " + passw.strip()
            else:
                return True
    f.close()
    return False


def printFail():
    print("Wrong master password or integrity check failed.")


args = sys.argv
# args = ['keePass.py', 'init', 'masterPassword']
# args = ['keePass.py', 'put', 'masterPassword', 'username3', 'pass3']
# args = ['keePass.py', 'get', 'masterPassword', 'username2']

masterPassword = ""
username = ""
password = ""

if args.__contains__("init"):
    masterPassword = str(args[2])
    f = open(inpFile, "a")
    f.close()
    encrypt(masterPassword)
    os.remove(inpFile)
    print("Password manager initialized")

if args.__contains__("get"):
    masterPassword = args[2]
    username = args[3]
    if decrypt(masterPassword):
        output = FindUsername(username, "get")
        if output != False:
            print(output)
        else:
            printFail()
        encrypt(masterPassword)
        os.remove(inpFile)
    else:
        printFail()

if args.__contains__("put"):
    masterPassword = args[2]
    username = args[3]
    password = args[4]
    structure = FormatCredentials(username, password)

    if decrypt(masterPassword):
        output = FindUsername(username, "put")
        if output != False:
            f = open(inpFile, "r")
            lines = f.readlines()
            f.close()
            newOutput = []
            newOutput.append(structure.__str__())

            for credential in lines:
                if not credential.__contains__(username):
                    newOutput.append(credential)

            random.shuffle(newOutput)  # add \n at random place and shuffle for end

            f = open(inpFile, "w")
            f.write("\n".join(newOutput))
            f.close()

        else:
            f = open(inpFile, "a")
            f.write(structure.__str__())
            f.close()

        encrypt(masterPassword)
        os.remove(inpFile)

    else:
        printFail()
