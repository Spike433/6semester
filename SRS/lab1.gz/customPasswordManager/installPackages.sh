version=$(python -V 2>&1 | grep -Po '(?<=Python )(.+)')
if [[ -z "$version" ]]
then
    echo "Python not installed"
fi

echo "Python installed: [OK]"

pip install virtualenv

#create virtualenv
python -m virtualenv .

echo 
echo "Activate virtual enviroment"
echo ". bin/activate"
#activate it
. bin/activate


#install pacakges
pip install pycryptodome

